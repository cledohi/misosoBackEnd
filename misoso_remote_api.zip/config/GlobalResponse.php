<?php
namespace App\Controllers;

class GlobalResponse
{
    public $status;
    public $message;
    public $body;
}