<?php
namespace App\Controllers;
use PDO;
class ApiAddress 
{
  public $Nidurl="http://10.20.1.4:8888/KYCService/findcitezen/";
  public $residanceurl ="http://192.168.30.10:8080/microinsuranceservices/";
  public $calculatePrime="http://192.168.30.10:8080/microcalculatorservices/calculator/protectioncredit/";
   
     
}

?>