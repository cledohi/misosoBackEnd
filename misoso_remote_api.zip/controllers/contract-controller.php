<?php
namespace App\Controllers;
use PDO;
use Exception;
use Slim\Http\UploadedFile;
use Quickshiftin\Pdf\Invoice\Invoice as PdfInvoice;
use Quickshiftin\Pdf\Invoice\Factory as InvoiceFactory;
class MisosoContract{
public function AgentContract($request,$response,$args){
   //return $pdf1 = new Zend_Pdf();
}
}